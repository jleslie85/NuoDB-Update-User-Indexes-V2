# Copyright (C) NuoDB, Inc. 2012-2017  All Rights Reserved.
#

use system;

Select 'Alter ' || 'table ' || schema || '.' || tablename || ' rebuild indexes;'
from system.tables
where schema != 'SYSTEM'
and type = 'TABLE';

